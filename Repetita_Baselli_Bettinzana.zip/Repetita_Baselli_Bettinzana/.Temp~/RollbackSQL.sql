-- Corso_Professore [rel14]
alter table `corso_professore_2`   drop foreign key `fk_corso_professore_2_corso_2`;
drop table `corso_professore_2`;
-- Agenda_Professore [rel13]
alter table `professore`   drop foreign key `fk_professore_agenda_2`;
alter table `professore`  drop column  `agenda_2_oid`;
-- Agenda_GiornoSettimana [rel12]
alter table `agenda_giornosettimana_2`   drop foreign key `fk_agenda_giornosettimana_2_gi`;
alter table `agenda_giornosettimana_2`   drop foreign key `fk_agenda_giornosettimana_2_ag`;
drop table `agenda_giornosettimana_2`;
-- GiornoSettimana_timeslot [rel11]
alter table `giornosettimana_timeslot_2`   drop foreign key `fk_giornosettimana_timeslot_3`;
alter table `giornosettimana_timeslot_2`   drop foreign key `fk_giornosettimana_timeslot_2`;
drop table `giornosettimana_timeslot_2`;
-- User_Group [User2Group_Group2User]
alter table `user_group_2`   drop foreign key `fk_user_group_2_group_2`;
alter table `user_group_2`   drop foreign key `fk_user_group_2_utente_2`;
drop table `user_group_2`;
-- User_DefaultGroup [User2DefaultGroup_DefaultGroup2User]
alter table `utente_2`   drop foreign key `fk_utente_2_group_2`;
alter table `utente_2`  drop column  `group_2_oid`;
-- Group_Module [Group2Module_Module2Group]
alter table `group_module_2`   drop foreign key `fk_group_module_2_module_2`;
alter table `group_module_2`   drop foreign key `fk_group_module_2_group_2`;
drop table `group_module_2`;
-- Group_DefaultModule [Group2DefaultModule_DefaultModule2Group]
alter table `group_2`   drop foreign key `fk_group_2_module_2`;
alter table `group_2`  drop column  `module_2_oid`;
-- Professore [ent1]
alter table `professore`   drop column  `attivo_2`;
-- Commento [ent9]
drop table `commento_2`;
-- Certificazione [ent7]
drop table `certificazione_2`;
-- Argomento [ent6]
drop table `argomento_2`;
-- Recensione [ent5]
drop table `recensione_2`;
-- Gestore [ent4]
drop table `gestore_2`;
-- Reclutatore [ent3]
drop table `reclutatore_2`;
-- TipologiaCertificazione [ent20]
drop table `tipologiacertificazione_2`;
-- Studente [ent2]
drop table `studente_2`;
-- Luogo [ent19]
drop table `luogo_2`;
-- Corso [ent18]
drop table `corso_2`;
-- Materia [ent17]
drop table `materia_2`;
-- FasciaOraria [ent14]
drop table `fasciaoraria_2`;
-- GiornoSettimana [ent13]
drop table `giornosettimana_2`;
-- Agenda [ent12]
drop table `agenda_2`;
-- Prenotazione [ent11]
drop table `prenotazione_2`;
-- Utente [User]
drop table `utente_2`;
-- Module [Module]
drop table `module_2`;
-- Group [Group]
drop table `group_2`;

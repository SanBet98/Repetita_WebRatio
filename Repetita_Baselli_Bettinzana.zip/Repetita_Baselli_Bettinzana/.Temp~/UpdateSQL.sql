-- PrenotazioneCorso [ent10]
create table `prenotazionecorso` (
   `prenotazione_oid`  integer  not null,
   `datainizio`  date,
   `datafine`  date,
  primary key (`prenotazione_oid`)
);


-- PrenotazioneArgomento [ent8]
create table `prenotazioneargomento` (
   `prenotazione_oid`  integer  not null,
   `giorno`  varchar(255),
   `ora`  time,
  primary key (`prenotazione_oid`)
);


-- GEN FK: PrenotazioneCorso --> Prenotazione
alter table `prenotazionecorso`   add index fk_prenotazionecorso_prenotazi (`prenotazione_oid`), add constraint fk_prenotazionecorso_prenotazi foreign key (`prenotazione_oid`) references `prenotazione` (`oid`);


-- GEN FK: PrenotazioneArgomento --> Prenotazione
alter table `prenotazioneargomento`   add index fk_prenotazioneargomento_preno (`prenotazione_oid`), add constraint fk_prenotazioneargomento_preno foreign key (`prenotazione_oid`) references `prenotazione` (`oid`);


-- Corso.prenotazioni [ent18#att67]
create view `corso_prenotazioni_view` as
select AL1.`oid` as `oid`, count(distinct AL2.`oid`) as `der_attr`
from  `corso` AL1 
               left outer join `prenotazione` AL2 on AL1.`oid`=AL2.`corso_oid`
group by AL1.`oid`;



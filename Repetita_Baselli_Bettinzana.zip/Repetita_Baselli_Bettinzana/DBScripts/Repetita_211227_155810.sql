-- Prenotazione [ent11]
alter table `prenotazione`  add column  `giorno_2`  varchar(255);



-- FasciaOraria [ent14]
alter table `fasciaoraria`  add column  `prenotata`  bit;


